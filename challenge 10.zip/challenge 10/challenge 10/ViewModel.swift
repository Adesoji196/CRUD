//
//  ViewModel.swift
//  challenge 10
//
//  Created by Turma02-1 on 23/10/26.
//

import Foundation
@Observable
class ViewModel {
    var personagens: [HaPo] = []
    
    private let service = Service ()
    
    func fetch () async {
        let url = "http://127.0.0.1:1880/readLetter"
        do {
            personagens = try await service.fetchPersonagens(url: url)
            print(personagens.count)
        } catch {
            print(error.localizedDescription)
        }
    }
}

