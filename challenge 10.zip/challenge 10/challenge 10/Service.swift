//
//  Service.swift
//  challenge 10
//
//  Created by Turma02-1 on 23/10/26.
//

import Foundation
struct Service {
    func fetchPersonagens(url: String) async throws -> [HaPo] {
        guard let url = URL(string: url) else {
            print("URL Error")
            fatalError("Wrong URL")
        }
        let (data,_) = try await URLSession.shared.data(from: url)
        let values = try JSONDecoder().decode([HaPo].self, from: data)
        return values
    }
}

