//
//  challenge_10App.swift
//  challenge 10
//
//  Created by Turma02-1 on 23/10/26.
//

import SwiftUI

@main
struct challenge_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
