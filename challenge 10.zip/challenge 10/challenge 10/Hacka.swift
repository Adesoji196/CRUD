//
//  Hacka.swift
//  challenge 10
//
//  Created by Turma02-1 on 23/10/26.
//

import Foundation
struct HaPo: Codable, Hashable {
    let place: String
    let year: Int?
}
