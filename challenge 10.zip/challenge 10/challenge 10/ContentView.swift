//
//  ContentView.swift
//  challenge 10
//
//  Created by Turma02-1 on 23/10/26.
//

import SwiftUI

struct ContentView: View {
    
    @State private var viewModel = ViewModel()
    
    var body: some View {
        ZStack {
            Color.red
            VStack {
                ScrollView {
                    ForEach(viewModel.personagens, id: \.self) {
                        e in
                        HStack {
                            Text(e.place)
                            
                        }
                    }
                }
            }
        }.task {
            await viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
